# LegalEase - AI-Powered Legal Document Generator

This package follows the folder/file structure of the AI-ML-and-GEN-AI-Track-Project-Template-main reference and contains LegalEase-specific documentation.

## Team
- Team ID: SWTID-2026-8297
- Team Leader: Ayisha Sameera B
- Team member: Priyadharshni D
- Team member: B Dhaniya
- Team member: L Bhavadharani
- Team member: Lathika J

## Project
LegalEase is an AI-powered legal document generator using Streamlit, FastAPI and Google Gemini. It supports document generation, preview/editing and TXT/DOCX/PDF export.

## Important
Performance values are not invented. Where actual load-test measurements were not present in the source project, the documentation marks them as not measured/to test.
